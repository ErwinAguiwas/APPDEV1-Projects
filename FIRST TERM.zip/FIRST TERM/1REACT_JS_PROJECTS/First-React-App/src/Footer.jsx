export default function Footer() {
    return(
        
        <footer>
            <p>
                &copy; {new Date().getFullYear()} My Food Website || Written By: Erwin Aguiwas
            </p>
        </footer>
    )
}
