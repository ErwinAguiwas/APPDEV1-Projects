function Footer() {
  return (
    <footer className="footer">
      <p>&copy; {new Date().getFullYear()} Erwin G. Aguiwas.</p>
    </footer>
  );
}

export default Footer;
