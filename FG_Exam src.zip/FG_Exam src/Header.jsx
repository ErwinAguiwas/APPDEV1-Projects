export default function Header() {
  return (
    <header className="header">
      <nav>
        <ul>
          <li><a href="#keyboard">KB-X1000</a></li>
        </ul>
      </nav>
    </header>
  );
}
