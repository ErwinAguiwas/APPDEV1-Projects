export default function Header() {
    //stateless component
    return (
        <>
        <header>
            <h1><center>My Color Picker: A Web Application</center></h1>
        </header>
        </>
    )
}