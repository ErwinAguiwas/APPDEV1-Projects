export default function Footer(){
    return(
        <footer>
            <hr />
            <p>My Counter Website || Written by: Erwin G. Aguiwas</p>
        </footer>
    )
}