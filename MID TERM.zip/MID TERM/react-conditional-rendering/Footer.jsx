export default function Footer(){
    return(
        <>
            <hr />
            <footer>
                <center>
                <p>&copy; {new Date().getFullYear()} My Other Food Website || Written by: Erwin G. Aguiwas</p>
                </center>
            </footer>
        </>
    )
}