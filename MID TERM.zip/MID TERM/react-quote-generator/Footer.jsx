export default function Footer() {
    return (
      <>
        <footer>
          <hr />
          <p>&copy; {new Date().getFullYear()} Quote Generator || Erwin G. Aguiwas</p>
        </footer>
      </>
    );
  }
  