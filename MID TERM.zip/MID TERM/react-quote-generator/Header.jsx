export default function Header() {
    return (
      <>
        <header>
          <h1><center>My Quote Generator: A Web Application</center></h1>
        </header>
      </>
    );
  }
  