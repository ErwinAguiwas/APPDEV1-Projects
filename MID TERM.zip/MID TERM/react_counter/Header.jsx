export default function Header(){
    return(
        <header>
            <h1>
                My Counter Project
            </h1>
            <hr />
        </header>
    )
}