export default function Header(){
    return(
        <header>
        <h1>This is my List Of Favorite Games:</h1>
        <hr />
        </header>
    )
    }