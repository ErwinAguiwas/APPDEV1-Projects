export default function Footer(){
    return(
        <footer>
            <hr />
            <p>&copy; {new Date().getFullYear() }My Games Website || Written by: Erwin G. Aguiwas</p>
        </footer>
    )
}