export default function Footer() {
    return(
        <>
        <footer>
            <hr/>
            <p>
            &copy; {new Date().getFullYear()} Color Picker || Erwin G. Aguiwas
            </p>
            </footer></>
    )
}